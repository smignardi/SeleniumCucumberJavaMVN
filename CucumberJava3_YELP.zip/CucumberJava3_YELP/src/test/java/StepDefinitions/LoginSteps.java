package StepDefinitions;

import io.cucumber.java.en.And;  
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.util.List;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.*;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import org.openqa.selenium.support.ui.*;

public class LoginSteps {


WebDriver driver=null; 

@Given("go to yelp")
public void go_to_yelp() throws InterruptedException {
	
	System.setProperty("webdriver.chrome.driver","/Users/stevenmignardi/Downloads/chromedriver"); 
	
    driver=new ChromeDriver();
    
    driver.get("https://www.yelp.com/");
    
    
    By verficadorPagina = By.xpath("//*[@id=\"logo\"]/a");
    WebDriverWait esperaExplicita = new WebDriverWait(driver,5);
    esperaExplicita.until(ExpectedConditions.visibilityOfElementLocated(verficadorPagina));

    
    driver.manage().window().maximize();
    
	
    System.out.println("Inside Step - Pagina Abierta");
}


@When("^search element (.*)$")
public void search_element_a(String type) {
    //CLICK EN EL DROPBOX
    driver.findElement(By.id("find_desc")).click();
    
    //INGRESAR LO QUE SE QUIERE BUSCAR
    driver.findElement(By.id("find_desc")).sendKeys(type);
    
    //CLICK BUSCAR
    driver.findElement(By.xpath("//*[@id=\"header-search-submit\"]")).click();
  
    
    By verficadorPagina = By.xpath("/html/body/yelp-react-root/div[1]/div[4]/div/div[2]/div/div/div/div/div/div/div/div/div[1]/div[3]");
    WebDriverWait esperaExplicita = new WebDriverWait(driver,5);
    esperaExplicita.until(ExpectedConditions.visibilityOfElementLocated(verficadorPagina));
}

@And("append pizza to the searched element")
public void append_pizza_to_the_searched_element() throws InterruptedException {
	 //APPEND PIZZA TO RESTAURANT
    driver.findElement(By.id("search_description")).sendKeys(" Pizza");
    
    //CLICK SEARCH 
    driver.findElement(By.xpath("//*[@id=\"header_find_form\"]/div/div[2]/div")).click();
    Thread.sleep(3000);
}

@When("report number of search results")
public void report_number_of_search_results() throws InterruptedException {
	//CUENTA LOS RESULTADOS EN LA PAGINA ACTUAL 
    List<WebElement> rows = driver.findElements(By.className("offscreen__09f24__1VFco"));
    System.out.println("La pagina actual de busqueda sin filtros nos muestra - " + rows.size()+ " resultados (con calificacion)");
    
    By verficadorPagina = By.xpath("/html/body/yelp-react-root/div[1]/div[4]/div/div[2]/div/div/div/div/div/div/div/div/div[1]/div[3]");
    WebDriverWait esperaExplicita = new WebDriverWait(driver,5);
    esperaExplicita.until(ExpectedConditions.visibilityOfElementLocated(verficadorPagina));
    
    Thread.sleep(2000);
}

@When("filtering precio {int}")
public void filtering_precio(Integer optionPrice) {
    
	
	if(optionPrice==0)
	{
	    driver.findElement(By.xpath("//html/body/yelp-react-root/div[1]/div[4]/div/div[1]/div[1]/div[1]/div/div[1]/div/div/div/button[1]")).click();
	}
	else if(optionPrice==1)
	{
		driver.findElement(By.xpath("//html/body/yelp-react-root/div[1]/div[4]/div/div[1]/div[1]/div[1]/div/div[1]/div/div/div/button[2]")).click();
	}
	else if(optionPrice==2)
	{
		driver.findElement(By.xpath("//html/body/yelp-react-root/div[1]/div[4]/div/div[1]/div[1]/div[1]/div/div[1]/div/div/div/button[3]")).click();
	}
	else
	{
		driver.findElement(By.xpath("//html/body/yelp-react-root/div[1]/div[4]/div/div[1]/div[1]/div[1]/div/div[1]/div/div/div/button[4]")).click();
	}
	
	
	By verficadorPagina = By.xpath("/html/body/yelp-react-root/div[1]/div[4]/div/div[2]/div/div/div/div/div/div/div/div/div[1]/div[3]");
	WebDriverWait esperaExplicita = new WebDriverWait(driver,5);
    esperaExplicita.until(ExpectedConditions.visibilityOfElementLocated(verficadorPagina));
	
}

@And("report stars rating")
public void report_stars_rating() throws InterruptedException {
    //RATING DE TODOS LOS RESULTADOS
    
    System.out.println("STARS RATING"); 
    List<WebElement> rating1 = driver.findElements(By.xpath("//div[@aria-label='1 star rating']"));
    if(rating1.size()>0) System.out.println("Results with 1 star rating - " + rating1.size()); 
    
    List<WebElement> rating1_5 = driver.findElements(By.xpath("//div[@aria-label='1.5 star rating']"));
    if(rating1_5.size()>0) System.out.println("Results with 1.5 star rating - " + rating1_5.size()); 
    
    List<WebElement> rating2 = driver.findElements(By.xpath("//div[@aria-label='2 star rating']"));
    if(rating2.size()>0) System.out.println("Results with 2 star rating - " + rating2.size()); 

    List<WebElement> rating2_5 = driver.findElements(By.xpath("//div[@aria-label='2.5 star rating']"));
    if(rating2_5.size()>0) System.out.println("Results with 2.5 star rating - " + rating2_5.size()); 
    
    List<WebElement> rating3 = driver.findElements(By.xpath("//div[@aria-label='3 star rating']"));
    if(rating3.size()>0) System.out.println("Results with 3 star rating - " + rating3.size()); 

    List<WebElement> rating3_5 = driver.findElements(By.xpath("//div[@aria-label='3.5 star rating']"));
    if(rating3_5.size()>0) System.out.println("Results with 3.5 star rating - " + rating3_5.size()); 
    
    List<WebElement> rating4 = driver.findElements(By.xpath("//div[@aria-label='4 star rating']"));
    if(rating4.size()>0) System.out.println("Results with 4 star rating - " + rating4.size()); 
    
    List<WebElement> rating4_5 = driver.findElements(By.xpath("//div[@aria-label='4.5 star rating']"));
    if(rating4_5.size()>0) System.out.println("Results with 4.5 star rating - " + rating4_5.size()); 
    
    List<WebElement> rating5 = driver.findElements(By.xpath("//div[@aria-label='5 star rating']"));
    if(rating5.size()>0) System.out.println("Results with 5 star rating - " + rating5.size()); 

    Thread.sleep(2000); 
}

@Then("get business info")
public void get_business_info() throws InterruptedException {
    //CLICK EN EL PRIMER RESTURANTE
    driver.findElement(By.xpath("//html/body/yelp-react-root/div[1]/div[4]/div/div[1]/div[1]/div[2]/div/ul/li[8]/div/div/div/div[2]/div[1]/div/div[2]")).click();
    
    Thread.sleep(3000);
    
    By verficadorPagina = By.xpath("//*[@id=\"wrap\"]/div[3]/yelp-react-root/div/div[2]/div[1]/div[1]/div/div/div[1]/h1");
    WebDriverWait esperaExplicita = new WebDriverWait(driver,5);
    esperaExplicita.until(ExpectedConditions.visibilityOfElementLocated(verficadorPagina));
    
    //ADDRESS
    String address = driver.findElement(By.xpath("//*[@id=\"wrap\"]/div[3]/yelp-react-root/div/div[3]/div/div/div[2]/div/div[2]/div/div/section[1]/div/div[3]/div/div[1]/p/p")).getText();
    System.out.println("Address - " + address); 
    
    //PHONE NO
    String phone = driver.findElement(By.xpath("//*[@id=\"wrap\"]/div[3]/yelp-react-root/div/div[3]/div/div/div[2]/div/div[2]/div/div/section[1]/div/div[2]/div/div[1]/p[2]")).getText();
    System.out.println("Phone - " + phone); 
  	    
    //WEBSITE
    String web = driver.findElement(By.xpath("//*[@id=\"wrap\"]/div[3]/yelp-react-root/div/div[3]/div/div/div[2]/div/div[2]/div/div/section[1]/div/div[1]/div/div[1]/p[2]/a")).getText();
    System.out.println("Web - " + web); 
  
    
    //FIRST 3 CUSTOMERS
    String first_customer = driver.findElement(By.xpath("//*[@id=\"wrap\"]/div[3]/yelp-react-root/div/div[3]/div/div/div[2]/div/div[1]/div[2]/section[2]/div[2]/div/ul/li[1]/div/div[1]/div/div[1]/div/div/div[2]/div[1]/span/a")).getText();
    System.out.println("First Customer Name - " + first_customer); 
  
    String second_customer = driver.findElement(By.xpath("//*[@id=\"wrap\"]/div[3]/yelp-react-root/div/div[3]/div/div/div[2]/div/div[1]/div[2]/section[2]/div[2]/div/ul/li[2]/div/div[1]/div/div[1]/div/div/div[2]/div[1]/span/a")).getText();
    System.out.println("Second Customer Name - " + second_customer); 
    
    String last_customer = driver.findElement(By.xpath("//*[@id=\"wrap\"]/div[3]/yelp-react-root/div/div[3]/div/div/div[2]/div/div[1]/div[2]/section[2]/div[2]/div/ul/li[3]/div/div[1]/div/div[1]/div/div/div[2]/div[1]/span/a")).getText();
    System.out.println("Last Customer Name - " + last_customer); 
}


@And("filtering distance {int}")
public void filtering_distance(Integer distance) throws InterruptedException {
	
	
	
	if(distance==0)
	{
	    driver.findElement(By.xpath("//html/body/yelp-react-root/div[1]/div[4]/div/div[1]/div[1]/div[1]/div/div[6]/div/div[2]/div[1]/label/div/div[1]/input")).click();
	}
	else if(distance==1)
	{
		driver.findElement(By.xpath("//html/body/yelp-react-root/div[1]/div[4]/div/div[1]/div[1]/div[1]/div/div[6]/div/div[2]/div[2]/label/div/div[1]/input")).click();
	}
	else if(distance==2)
	{
		driver.findElement(By.xpath("//html/body/yelp-react-root/div[1]/div[4]/div/div[1]/div[1]/div[1]/div/div[6]/div/div[2]/div[3]/label/div/div[1]/input")).click();
	}
	else if(distance==3)
	{
		driver.findElement(By.xpath("//html/body/yelp-react-root/div[1]/div[4]/div/div[1]/div[1]/div[1]/div/div[6]/div/div[2]/div[4]/label/div/div[1]/input")).click();
	}
	else
	{
		driver.findElement(By.xpath("//html/body/yelp-react-root/div[1]/div[4]/div/div[1]/div[1]/div[1]/div/div[6]/div/div[2]/div[5]/label/div/div[1]/input")).click();
	}
	
	
    By verficadorPagina = By.xpath("/html/body/yelp-react-root/div[1]/div[4]/div/div[2]/div/div/div/div/div/div/div/div/div[1]/div[3]");
    WebDriverWait esperaExplicita = new WebDriverWait(driver,5);
    esperaExplicita.until(ExpectedConditions.visibilityOfElementLocated(verficadorPagina));
     
    Thread.sleep(2000);
    
}

}








